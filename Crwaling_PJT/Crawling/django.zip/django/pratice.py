a = ' da a a a ad '

print(a)